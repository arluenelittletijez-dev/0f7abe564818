// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Publish QoS2 message\n", stdout);
  return lionss_run_workload("mqtt-qos2");
}
