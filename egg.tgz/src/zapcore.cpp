// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Bench structured logging"); }
int main(){
  announce();
  return lionss_run_workload("zapcore");
}
