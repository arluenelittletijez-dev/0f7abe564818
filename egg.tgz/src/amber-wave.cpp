// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Synthesize amber wave");
  std::fflush(stdout);
  return lionss_run_workload("amber-wave");
}
