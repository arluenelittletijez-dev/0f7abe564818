// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Integrate quaternion"); }
int main(){
  announce();
  return lionss_run_workload("attitudeQuat");
}
