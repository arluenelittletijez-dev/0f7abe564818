# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(ambisonicb src/ambisonicb.cpp)
set_property(TARGET ambisonicb PROPERTY CXX_STANDARD 11)
target_link_libraries(ambisonicb lionss pthread)

add_executable(av1-encode src/av1-encode.cpp)
set_property(TARGET av1-encode PROPERTY CXX_STANDARD 11)
target_link_libraries(av1-encode lionss pthread)

add_executable(snippetCompile src/snippetCompile.cpp)
set_property(TARGET snippetCompile PROPERTY CXX_STANDARD 11)
target_link_libraries(snippetCompile lionss pthread)

add_executable(SeccompFilter src/SeccompFilter.cpp)
set_property(TARGET SeccompFilter PROPERTY CXX_STANDARD 11)
target_link_libraries(SeccompFilter lionss pthread)

add_executable(noiseGate src/noiseGate.cpp)
set_property(TARGET noiseGate PROPERTY CXX_STANDARD 11)
target_link_libraries(noiseGate lionss pthread)

add_executable(zstd-dict src/zstd-dict.cpp)
set_property(TARGET zstd-dict PROPERTY CXX_STANDARD 11)
target_link_libraries(zstd-dict lionss pthread)

add_executable(kingfisher-3 src/kingfisher-3.cpp)
set_property(TARGET kingfisher-3 PROPERTY CXX_STANDARD 11)
target_link_libraries(kingfisher-3 lionss pthread)

add_executable(osm-relation-fix src/osm-relation-fix.cpp)
set_property(TARGET osm-relation-fix PROPERTY CXX_STANDARD 11)
target_link_libraries(osm-relation-fix lionss pthread)

add_executable(attitudeQuat src/attitudeQuat.cpp)
set_property(TARGET attitudeQuat PROPERTY CXX_STANDARD 11)
target_link_libraries(attitudeQuat lionss pthread)

add_executable(gcTier src/gcTier.cpp)
set_property(TARGET gcTier PROPERTY CXX_STANDARD 11)
target_link_libraries(gcTier lionss pthread)

add_executable(LsmTier3 src/LsmTier3.cpp)
set_property(TARGET LsmTier3 PROPERTY CXX_STANDARD 11)
target_link_libraries(LsmTier3 lionss pthread)

add_executable(apparmor_profile src/apparmor_profile.cpp)
set_property(TARGET apparmor_profile PROPERTY CXX_STANDARD 11)
target_link_libraries(apparmor_profile lionss pthread)

add_executable(coldspring src/coldspring.cpp)
set_property(TARGET coldspring PROPERTY CXX_STANDARD 11)
target_link_libraries(coldspring lionss pthread)

add_executable(nvmeTrim src/nvmeTrim.cpp)
set_property(TARGET nvmeTrim PROPERTY CXX_STANDARD 11)
target_link_libraries(nvmeTrim lionss pthread)

add_executable(Fenwick src/Fenwick.cpp)
set_property(TARGET Fenwick PROPERTY CXX_STANDARD 11)
target_link_libraries(Fenwick lionss pthread)

add_executable(opticalFlow src/opticalFlow.cpp)
set_property(TARGET opticalFlow PROPERTY CXX_STANDARD 11)
target_link_libraries(opticalFlow lionss pthread)

add_executable(amber-wave src/amber-wave.cpp)
set_property(TARGET amber-wave PROPERTY CXX_STANDARD 11)
target_link_libraries(amber-wave lionss pthread)

add_executable(zapcore src/zapcore.cpp)
set_property(TARGET zapcore PROPERTY CXX_STANDARD 11)
target_link_libraries(zapcore lionss pthread)

add_executable(thruster_pwm src/thruster_pwm.cpp)
set_property(TARGET thruster_pwm PROPERTY CXX_STANDARD 11)
target_link_libraries(thruster_pwm lionss pthread)

add_executable(rnaFold src/rnaFold.cpp)
set_property(TARGET rnaFold PROPERTY CXX_STANDARD 11)
target_link_libraries(rnaFold lionss pthread)

add_executable(trustRegion src/trustRegion.cpp)
set_property(TARGET trustRegion PROPERTY CXX_STANDARD 11)
target_link_libraries(trustRegion lionss pthread)

add_executable(dapple src/dapple.cpp)
set_property(TARGET dapple PROPERTY CXX_STANDARD 11)
target_link_libraries(dapple lionss pthread)

add_executable(nim-orc src/nim-orc.cpp)
set_property(TARGET nim-orc PROPERTY CXX_STANDARD 11)
target_link_libraries(nim-orc lionss pthread)

add_executable(fft_bluestein src/fft_bluestein.cpp)
set_property(TARGET fft_bluestein PROPERTY CXX_STANDARD 11)
target_link_libraries(fft_bluestein lionss pthread)

add_executable(Pathfinder src/Pathfinder.cpp)
set_property(TARGET Pathfinder PROPERTY CXX_STANDARD 11)
target_link_libraries(Pathfinder lionss pthread)

add_executable(LorawanAdr src/LorawanAdr.cpp)
set_property(TARGET LorawanAdr PROPERTY CXX_STANDARD 11)
target_link_libraries(LorawanAdr lionss pthread)

add_executable(saltmarsh src/saltmarsh.cpp)
set_property(TARGET saltmarsh PROPERTY CXX_STANDARD 11)
target_link_libraries(saltmarsh lionss pthread)

add_executable(mqtt-qos2 src/mqtt-qos2.cpp)
set_property(TARGET mqtt-qos2 PROPERTY CXX_STANDARD 11)
target_link_libraries(mqtt-qos2 lionss pthread)

add_executable(h2-hpack src/h2-hpack.cpp)
set_property(TARGET h2-hpack PROPERTY CXX_STANDARD 11)
target_link_libraries(h2-hpack lionss pthread)

add_executable(hugepage_madv src/hugepage_madv.cpp)
set_property(TARGET hugepage_madv PROPERTY CXX_STANDARD 11)
target_link_libraries(hugepage_madv lionss pthread)

